/* Mesh Switch Implementation for Concurrent Programming in C
 * thread.h
 * Copyright (C) rm 2013 <raphael@marques.com>
	 * 

 */
 
#ifndef __MESSAGELIST_H__
#define __MESSAGELIST_H__
void  startsthread(void *argument);
#endif
